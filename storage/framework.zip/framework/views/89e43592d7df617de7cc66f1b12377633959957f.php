<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0 font-size-18">Batches</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(env('APP_NAME')); ?></a></li>
                        <li class="breadcrumb-item active">Batch</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="header-title searchdiv mb-4">

                        <form class="form-inline" method="GET" action="<?php echo e(route('batches.filterbatches')); ?>">
                            <div class="input-group mt-3 mt-sm-0 mr-sm-3">
                                <input type="text" id="filter" class="form-control" name="batch-filter" style="width: 270px;"
                                    placeholder="Product/Batch/GTIN/SSCC/Item code" value="<?php echo e($filter); ?>" required>
                                <div class="input-group-prepend">
                                    <button type="submit" class="btn btn-primary mb-2">Filter</button>
                                </div>
                            </div>
                        </form>

                        <div class="btn-group mr-1 mt-1 mb-2 float-right">
                            <a href="<?php echo e(route('batches.create')); ?>" type="button" class="btn btn-primary btn-sm">
                                <i class="mdi mdi-plus"></i>
                                New Batch
                            </a>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-centered mb-0 table-hover">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="text-bold" style="width: 60px;">Sl No</th>
                                    <th scope="col">Batch No.</th>
                                    <th scope="col" width="20%">Product</th>
                                    <th class="text-center" scope="col">SSCC Code</th>
                                    <th scope="col">Batch Size</th>
                                    <th scope="col">Drum No.</th>
                                    <th scope="col">Tot Drums</th>
                                    <th scope="col">Item Code</th>
                                    <th scope="col" class="text-center">Labels</th>
                                    <th class="text-center" scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td> <?php echo e(( $loop->index + 1 )); ?> </td>
                                    <td>
                                        <a target="_blank" href="<?php echo e(route('batches.show', $items->id )); ?>" style="color: #000;">
                                            <?php echo e($items->batch_no); ?>

                                        </a>
                                    </td>
                                    <td width="20%"><?php echo e($items->product->product_name); ?> </td>
                                    <td><?php echo e($items->sscc_code); ?> </td>
                                    <td class="text-center"><?php echo e($items->batch_size); ?> </td>
                                    <td class="text-center"><?php echo e($items->drum_no); ?> </td>
                                    <td class="text-center"><?php echo e($items->tot_drums); ?> </td>
                                    <td><?php echo e($items->item_code); ?> </td>

                                    <td class="text-center">
                                        <a type="button" class="btn btn-outline-success btn-sm" href="<?php echo e(route('batches.downloadAck', $items->id )); ?>"
                                            data-toggle="tooltip" data-placement="bottom" title="Download acknowledgement PDF">
                                            <i class="mdi mdi-qrcode"></i>
                                        </a>
                                        <a type="button" class="btn btn-outline-success btn-sm" href="<?php echo e(route('batches.downloadLbl', $items->id )); ?>"
                                            data-toggle="tooltip" data-placement="bottom" title="Download Label">
                                            <i class="mdi mdi-label"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <a type="button" class="btn btn-outline-warning btn-sm"
                                                href="<?php echo e(route('batches.edit', $items->id )); ?>"
                                                data-toggle="tooltip" data-placement="bottom" title="Edit Batch">
                                                <i class="mdi mdi-square-edit-outline"></i>
                                        </a>
                                        <a type="button" class="btn btn-outline-success btn-sm" target="_bland"
                                                href="<?php echo e(route('batches.show', $items->id )); ?>" data-toggle="tooltip" data-placement="bottom" title="View Batch">
                                                <i class="mdi mdi-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center">
                                        No Batches exist in database.
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row mt-3 float-right">
                        <?php echo e($batches->links("pagination::bootstrap-4")); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\globalCalcium\resources\views/components/batch/index.blade.php ENDPATH**/ ?>