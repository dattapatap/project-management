<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <style>
        @page  {
            margin: 5%;
            size: letter;
        }
    </style>
</head>
<body>
    <div style="width: 99.6%;border: 3px solid red;padding:2px;">
        <table style="width: 100%;border: 2px solid red;padding:5px;">
            <tbody>
                <tr style="width: 100%;">
                    <td style="width: 10%">
                        <img src="global-img/client1.png" alt="Brand" style="height: 80px">
                    </td>
                    <td style="text-align: center; width: 90%">
                        <h2 style="color:#1387a1;margin-bottom: 3px !important;font-family:Times New Roman;font-size: 16pt;">
                            <b>GLOBAL </b><span style="color:#8bbe91;"><b>CALCIUM</b></span></h2>
                        <h3 style="margin:3px">  <?php echo e($batch['product']['product_name']); ?> </h3>
                        <h4 style="margin:3px">(ITEM CODE: <?php echo e($batch['item_code']); ?> )</h4>
                    </td>
                </tr>
            </tbody>
        </table>
        <table style="width: 100%;border: 2px solid red;border-top:1px solid red !important">
            <tbody>
                <tr style="color: #000;font-size: 18px;font-weight: 600; width: 100%">
                    <td>Batch No</td>
                    <td>:</td>
                    <td><?php echo e($batch['batch_no']); ?></td>
                    <td></td>
                    <td>Gross Wt.</td>
                    <td>:</td>
                    <td>  <?php echo e($batch['gross_weight']); ?> Kg.</td>
                </tr>
                <tr style="color: #000;font-size: 18px;font-weight: 600;">

                    <td>Mfg.Date</td>
                    <td>:</td>
                    <td> <?php echo e(Carbon\Carbon::parse($batch['manf_date'])->format('d-m-Y')); ?> </td>
                    <td></td>
                    <td>Tare Wt</td>
                    <td>:</td>
                    <td><?php echo e($batch['tare_weight']); ?> Kg.</td>
                </tr>
                <tr style="color: #000;font-size: 18px;font-weight: 600;">
                    <td>EXP.Date</td>
                    <td>:</td>
                    <td> <?php echo e(Carbon\Carbon::parse($batch['exp_date'])->format('d-m-Y')); ?> </td>
                    <td></td>
                    <td>Net Wt.</td>
                    <td>:</td>
                    <td> <?php echo e($batch['net_weight']); ?> Kg.</td>

                </tr>
                <tr style="color: #000;font-size: 18px;font-weight: 600;">
                    <td>Mfg.Lic.No</td>
                    <td>:</td>
                    <td><?php echo e($batch['manf_lic_no']); ?></td>
                    <td style="width: 20%"></td>
                    <td rowspan="2">Total No. Of Drums</td>
                    <td rowspan="2">:</td>
                    <td rowspan="2">  <?php echo e($batch['tot_drums']); ?> </td>

                </tr>

                <tr style="color: #000;font-size: 18px;font-weight: 600;">
                    <td>Drum.No</td>
                    <td>:</td>
                    <td> <?php echo e($batch['drum_no']); ?> </td>

                </tr>
            </tbody>
        </table>
        <table style="width: 100%;border-top:1px solid red !important;border: 2px solid red;">
            <tbody>
                <tr style="text-align: right;margin-rigth:5px!important;">
                    <td colspan="2">
                        <h3 style="color:#8bbe91;margin: 0px;">DO NOT EXPOSE TO MOISTURE AND DIRECT SUNLIGHT</h3>
                        <h3 style="color:#000;margin: 0px;padding-top:20px;"> <?php echo e($batch['storage_condition']); ?> </h3>
                    </td>
                </tr>
            </tbody>
        </table>
        <table style="width: 100%;border-top:1px solid red !important;border: 2px solid red;">
            <tbody>
                <tr>
                    <td>
                        <h5 style=" width: 270px;color: #1387a1;font-weight: 700;margin:0px;">MANUFACTURED BY : </h5>
                        <h5 style=" width: 270px;color: #1387a1;font-weight: 700;margin:0px"><?php echo e($batch['brand']['company_name']); ?> </h5>
                        <h5 style=" width: 270px;color: #1387a1;font-weight: 700;margin:0px">
                            <?php echo e($batch['brand']['address']); ?>

                        </h5>
                    </td>
                    <td>
                        <img src="global-img/chart.png" alt="qrcode" style="width:80px;">
                    </td>
                    <td style="text-align: right;">
                        <h4 style="color:#8bbe91;margin-bottom:10px;align-item:right;margin:0px;">eGMP,HACCP,ISO9001,ISOI4001 Approved Facility</h4>
                        <img src="global-img/client2.png" alt="footer-logo" style="height: 50px;">
                    </td>
                </tr>

            </tbody>

        </table>
        <table style="width: 100%;border-top:1px solid red !important;border: 2px solid red;">
            <tr>
                <td><b style="font-size: 7pt;padding: 5px;">FORMAT NO. : QA035-F16-02<b></td>
            </tr>
        </table>
    </div>

</body>
<html>
`
<?php /**PATH D:\globalCalcium\resources\views/global.blade.php ENDPATH**/ ?>