<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0 font-size-18">Brands</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(env('APP_NAME')); ?></a></li>
                        <li class="breadcrumb-item active">Brands</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="header-title mb-4">
                        <div class="btn-group mr-1 mt-1 mb-2 float-right">
                            <a href="<?php echo e(route('brands.create')); ?>" type="button" class="btn btn-primary btn-sm">
                                <i class="mdi mdi-plus"></i>
                                New Brand
                            </a>

                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-centered mb-0 table-hover">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="width: 60px;">Sl No</th>
                                    <th scope="col">Brand Name</th>
                                    <th scope="col">Code</th>
                                    <th scope="col">Company Name</th>
                                    <th scope="col" width="20%">Address</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td> <?php echo e($loop->index + 1); ?> </td>
                                    <td> <?php echo e($items->brand_name); ?> </td>
                                    <td><?php echo e($items->Code); ?> </td>
                                    <td><?php echo e($items->company_name); ?>   </td>
                                    <td width="20%"><?php echo e($items->address); ?></td>
                                    <td>
                                        <?php if($items->status == true): ?>
                                            <a href="<?php echo e(route('brands.changeStatus', $items->id )); ?>" class="btn btn-success btn-sm">Active</a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('brands.changeStatus', $items->id )); ?>" class="btn btn-danger btn-sm">In-Active</a>
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <form method="post" action="<?php echo e(route('brands.destroy',[$items->id])); ?>"  style="display: inline-block;">
                                            <a type="button" class="btn btn-outline-success btn-sm"
                                                href="<?php echo e(route('brands.edit', $items->id )); ?>">
                                                Edit
                                            </a>

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="submit" value="Delete" class="btn btn-outline-danger btn-sm">
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center">
                                        No Brands exist.
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row mt-3 float-right">
                        <?php echo e($brands->links("pagination::bootstrap-4")); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\globalCalcium\resources\views/components/brands/index.blade.php ENDPATH**/ ?>