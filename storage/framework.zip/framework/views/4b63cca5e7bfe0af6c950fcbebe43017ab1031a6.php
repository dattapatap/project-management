<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
    <link href="<?php echo e(asset('assets/libs/slick-slider/slick/slick.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/libs/slick-slider/slick/slick-theme.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/libs/jqvmap/jqvmap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- alertifyjs Css -->
    <link href="<?php echo e(asset('assets/libs/alertifyjs/build/css/alertify.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- alertifyjs default themes  Css -->
    <link href="<?php echo e(asset('assets/libs/alertifyjs/build/css/themes/default.min.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css"/>
    <link href="<?php echo e(asset('assets/css/select2.css')); ?>" rel="stylesheet" type="text/css">
    <script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body data-topbar="dark" data-layout="horizontal">
    <!-- Begin page -->
    <div id="layout-wrapper">

        <header id="page-topbar">
            <div class="navbar-header">
                <div class="d-flex">
                    <div class="navbar-brand-box">
                        <a href="<?php echo e(url('/')); ?>" class="logo logo-dark">
                            <span class="logo-sm">
                                <img src="<?php echo e(asset('assets/images/logo-sm-light.png')); ?>" alt="" height="30">
                            </span>
                            <span class="logo-lg">
                                <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" alt="" height="40">
                            </span>
                        </a>

                        <a href="<?php echo e(url('/')); ?>" class="logo logo-light">
                            <span class="logo-sm">
                                <img src="<?php echo e(asset('assets/images/logo-sm-light.png')); ?>" alt="" height="30">
                            </span>
                            <span class="logo-lg">
                                <img src="<?php echo e(asset('assets/images/logo-light.png')); ?>" alt="" height="40">
                            </span>
                        </a>
                    </div>
                    <button type="button" class="btn btn-sm mr-2 font-size-16 d-lg-none header-item waves-effect waves-light" data-toggle="collapse" data-target="#topnav-menu-content">
                        <i class="fa fa-fw fa-bars"></i>
                    </button>
                </div>

                <div class="d-flex">
                    <div class="dropdown d-inline-block">
                        <button type="button" class="btn header-item waves-effect"
                            id="page-header-user-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <!-- <img class="rounded-circle header-profile-user" src="assets/images/users/avatar-1.jpg" alt="Header Avatar"> -->
                            <span class="d-none d-sm-inline-block ml-1"><?php echo e(Auth::user()->name); ?></span>
                            <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <!-- item-->
                            
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <i class="mdi mdi-logout font-size-16 align-middle mr-1"></i> Logout
                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </header>

        <div class="topnav">
            <div class="container-fluid">
                <nav class="navbar navbar-light navbar-expand-lg topnav-menu">

                    <div class="collapse navbar-collapse" id="topnav-menu-content">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/')); ?>">
                                    <i class="mdi mdi-storefront mr-2"></i>Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/brands')); ?>">
                                    <i class="mdi mdi-package-variant-closed mr-2"></i>Brands
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/products')); ?>">
                                    <i class="mdi mdi-cloud-print-outline mr-2"></i>Products
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/batches')); ?>">
                                    <i class="mdi mdi-package-variant-closed mr-2"></i>Batches
                                </a>
                            </li>



                        </ul>
                    </div>
                </nav>
            </div>
        </div>

        <!-- ============================================================== -->
        <!-- Start main-content -->
        <!-- ============================================================== -->



        <div class="main-content">

            <div class="page-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- End Page-content -->

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            2022 © <?php echo e(env('APP_NAME')); ?>.
                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-right d-none d-sm-block">
                                Created with <i class="mdi mdi-heart text-danger"></i> by <a href="https://digitalnock.com/" target="_blank">Digitalnock It Solutions.</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <div class="rightbar-overlay"></div>

    <!-- JAVASCRIPT -->
    <script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>
    <!-- apexcharts -->
    <script src="<?php echo e(asset('assets/libs/slick-slider/slick/slick.min.js')); ?>"></script>
    <!-- Jq vector map -->
    <script src="<?php echo e(asset('assets/libs/alertifyjs/build/alertify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jqvmap/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <?php if(\Session::has('error')): ?>
        <script>
            alertify.error("<?php echo \Session::get('error'); ?>");
        </script>
    <?php endif; ?>
    <?php if(\Session::has('success')): ?>
        <script>
            alertify.success("<?php echo \Session::get('success'); ?>");
        </script>
    <?php endif; ?>
</body>
</html>
<?php /**PATH D:\globalCalcium\resources\views/layouts/app.blade.php ENDPATH**/ ?>