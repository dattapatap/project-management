<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <style>
        @page  {
            margin: 5%;
            size: letter;
        }
        table {
            border-collapse: collapse;
            border-spacing: 0;
            width: 100%;
        }

        #content th,
        td {
            text-align: left;
            padding: 8px;
        }

        #content th {

            border: 1px solid #aeaeae;
        }

        #content td {
            border-left: 1px solid #aeaeae;
            border-right: 1px solid #aeaeae;
        }

        #content  tbody  tr td:first-child {
           text-align: center;
        }


    </style>

</head>
<body>

    <div class="" style="width: 100%;">
        <table style="width: 100%;">
            <tbody>
                <tr style="width: 100%;">
                    <td style="text-align: center;margin-bottom:20px;">
                        <img src="global-img/client1.png" alt="Brand">
                    </td>
                </tr>
            </tbody>
        </table>
        <table id="content" style=" border: 1px solid #aeaeae;">
            <thead>
                <tr>
                    <th width="7%">SL No</th>
                    <th width="45%" style="text-align: center;">Principals</th>
                    <th width="48%" style="text-align: center;">Description</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td >01</td>
                    <td>Unique Product Identification Code</td>
                    <td> <?php echo e($batch['gtin_no']); ?> </td>

                </tr>
                <tr>
                    <td>02</td>
                    <td>Name Of the API </td>
                    <td> <?php echo e($batch['product']['product_name']); ?> </td>

                </tr>
                <tr>
                    <td>03</td>
                    <td>Brand Name</td>
                    <td>  <?php echo e($batch['brand']['brand_name']); ?> </td>

                </tr>
                <tr>
                    <td>04</td>
                    <td>Name and Address of the manufacturer Name</td>
                    <td>
                        <?php echo e($batch['brand']['company_name']); ?>

                        <br>
                        <?php echo e($batch['brand']['address']); ?>

                    </td>

                </tr>
                <tr>
                    <td>05</td>
                    <td>Batch No.</td>
                    <td> <?php echo e($batch['batch_no']); ?> </td>

                </tr>

                <tr>
                    <td>06</td>
                    <td>Batch Size</td>
                    <td> <?php echo e($batch['batch_size']); ?> </td>

                </tr>
                <tr>
                    <td>07</td>
                    <td>Date Of manufacturing</td>
                    <td>  <?php echo e(Carbon\Carbon::parse($batch['manf_date'])->format('d-m-Y')); ?> </td>

                </tr>
                <tr>
                    <td>08</td>
                    <td>Date Of expiry or retesting </td>
                    <td>  <?php echo e(Carbon\Carbon::parse($batch['exp_date'])->format('d-m-Y')); ?> </td>

                </tr>
                <tr>
                    <td>09</td>
                    <td>Serial shipping container code</td>
                    <td> <?php echo e($batch['sscc_code']); ?> </td>

                </tr>
                <tr>
                    <td>10</td>
                    <td>Manufacturing license no. or import license no.</td>
                    <td>  <?php echo e($batch['manf_lic_no']); ?> </td>

                </tr>
                <tr>
                    <td>11</td>
                    <td>Special storage conditions required</td>
                    <td> <?php echo e($batch['storage_condition']); ?> </td>

                </tr>

            </tbody>
        </table>
        <table  style=" border: 1px solid #aeaeae;">
            <tbody>
                <tr>
                    <td style="text-align: left;">
                        <h5 style=" width: 270px;font-weight: 700;margin:0px;">MANUFACTURED BY : </h5>
                        <h5 style=" width: 270px;font-weight: 700;margin:0px"><?php echo e($batch['brand']['company_name']); ?> </h5>
                        <h5 style=" width: 270px;font-weight: 700;margin:0px">
                            <?php echo e($batch['brand']['address']); ?>

                        </h5>
                    </td>
                    <td style="text-align: right;">
                        <h4 style="color:#8bbe91;margin-bottom:10px;align-item:right;margin:0px;">eGMP,HACCP,ISO9001,ISOI4001 Approved Facility</h4>
                        <img src="global-img/client2.png" alt="footer-logo" style="height: 80px;">
                    </td>
                </tr>

            </tbody>

        </table>
    </div>
</body>

</html>
<?php /**PATH D:\globalCalcium\resources\views/acknowlagement.blade.php ENDPATH**/ ?>