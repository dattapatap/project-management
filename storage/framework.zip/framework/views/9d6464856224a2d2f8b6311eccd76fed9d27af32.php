<?php $__env->startSection('content'); ?>
<style>
</style>
<div class="container-fluid">
   <!-- start page title -->
   <div class="row">
      <div class="col-12">
         <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0 font-size-18">Batch</h4>
            <div class="page-title-right">
               <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(env('APP_NAME')); ?></a></li>
                  <li class="breadcrumb-item"><a href="<?php echo e(url('/batches')); ?>">Batch</a></li>
                  <li class="breadcrumb-item active"> Batch Details</li>
               </ol>
            </div>
         </div>
      </div>
   </div>
   <!-- end page title -->
   <div class="row">
      <div class="col-lg-12">
            <div id="print-area" class="printpreview">
                <table class="batchdiv" width="100%" align="center">
                    <tbody>
                        <tr class="masthead">
                            <td colspan="100" align="center">BATCH DETAILS</td>
                        </tr>

                        <tr class="odd">
                            <td><strong>Brand Name</strong></td>
                            <td><?php echo e($batch->brand->brand_name); ?></td>
                            <td><strong>Product Name</strong></td>
                            <td> <?php echo e($batch->product->product_name); ?> </td>
                        </tr>

                        <tr class="odd">
                            <td><strong>GTIN Number</strong></td>
                            <td> <?php echo e($batch->product->gtin_no); ?>  </td>
                            <td><strong>Company Name</strong></td>
                            <td><?php echo e($batch->brand->company_name); ?> </td>
                        </tr>

                        <tr class="even">
                            <td><strong>Product Description</strong></td>
                            <td colspan="3"><?php echo e($batch->description); ?></td>
                        </tr>

                        <tr class="odd">
                            <td><strong class="mainheading">GTIN Number</strong></td>
                            <td colspan="3"> <?php echo e($batch->gtin_no); ?></td>
                        </tr>
                        <tr class="even">
                            <td><strong>Batch Number</strong></td>
                            <td> <?php echo e($batch->batch_no); ?></td>
                            <td><strong>Batch Size</strong></td>
                            <td> <?php echo e($batch->batch_size); ?></td>
                        </tr>
                        <tr class="even">
                            <td><strong>SSCC Code</strong></td>
                            <td colspan="3"><?php echo e($batch->sscc_code); ?></td>
                        </tr>
                        <tr class="even">
                            <td><strong>Gross Weight</strong></td>
                            <td> <?php echo e($batch->gross_weight); ?> </td>
                            <td><strong>Tare Weight</strong></td>
                            <td><?php echo e($batch->tare_weight); ?></td>
                        </tr>
                        <tr class="even">
                            <td><strong>Net Weight</strong></td>
                            <td colspan="3"> <?php echo e($batch->net_weight); ?> </td>
                        </tr>
                        <!-- ###Detailed_Attributes### -->

                        <tr>
                            <td colspan="4"><strong class="mainheading">Quantities</strong></td>
                        </tr>
                        <tr class="even">
                            <td><strong>Drum Number</strong></td>
                            <td > <?php echo e($batch->drum_no); ?> </td>
                            <td><strong>Total Drums</strong></td>
                            <td > <?php echo e($batch->tot_drums); ?></td>
                        </tr>
                        <tr class="even">
                            <td><strong>Manufature Date</strong></td>
                            <td> <?php echo e(Carbon\Carbon::parse($batch->manf_date)->format('d-m-Y')); ?></td>
                            <td><strong>Expity Date</strong></td>
                            <td> <?php echo e(Carbon\Carbon::parse($batch->exp_date)->format('d-m-Y')); ?></td>
                        </tr>
                        <tr class="even">
                            <td><strong>Manufacture Licence Number</strong></td>
                            <td colspan="3"> <?php echo e($batch->manf_lic_no); ?></td>
                        </tr>
                        <tr class="even">
                            <td><strong>Item Code</strong></td>
                            <td><?php echo e($batch->item_code); ?></td>
                            <td><strong>Shipping Code</strong></td>
                            <td><?php echo e($batch->shipping_code); ?></td>
                        </tr>
                        <tr class="odd">
                            <td><strong>Storage Condition</strong></td>
                            <td colspan="3"><?php echo e($batch->storage_condition); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
      </div>
   </div>
   <!-- end row -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
   $(document).ready(function(){

   })

   function isNumberKey(evt){
       var charCode = (evt.which) ? evt.which : evt.keyCode;
       if (charCode > 31 && (charCode < 48 || charCode > 57))
           return false;
       return true;
   }


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\globalCalcium\resources\views/components/batch/show.blade.php ENDPATH**/ ?>