<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0 font-size-18">Products</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(env('APP_NAME')); ?></a></li>
                        <li class="breadcrumb-item active">Products</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="header-title searchdiv mb-4">

                        <form class="form-inline" method="GET" action="<?php echo e(route('products.filterproduct')); ?>">
                            <div class="input-group mt-3 mt-sm-0 mr-sm-3">
                                <input type="text" id="filter" class="form-control" name="product-filter" style="width: 250px;"
                                    placeholder="Product/Brand/GTIN" value="<?php echo e($filter); ?>" required>
                                <div class="input-group-prepend">
                                    <button type="submit" class="btn btn-primary mb-2">Filter</button>
                                </div>
                            </div>

                        </form>

                        <div class="btn-group mr-1 mt-1 mb-2 float-right">
                            <button type="button" class="btn btn-primary dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Action  <i class="mdi mdi-chevron-down"></i>
                            </button>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="<?php echo e(route('products.create')); ?>">Add Product</a>
                                <a class="dropdown-item" href="<?php echo e(route('products.upload')); ?>">Upload Product</a>
                            </div>
                        </div><!-- /btn-group -->
                    </div>

                    <div class="table-responsive">
                        <table class="table table-centered mb-0 table-hover">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="width: 60px;">Sl No</th>
                                    <th scope="col">Brand Name</th>
                                    <th scope="col">Product Name</th>
                                    <th scope="col">GTIN Code</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td> <?php echo e(( $loop->index + 1 )); ?> </td>
                                    <td> <?php echo e($items->brand->brand_name); ?> </td>
                                    <td><?php echo e($items->product_name); ?> </td>
                                    <td><?php echo e($items->gtin_no); ?>   </td>                                    <td>
                                        <?php if($items->status == true): ?>
                                            <a href="<?php echo e(route('products.changeStatus', $items->id )); ?>" class="btn btn-success btn-sm">Active</a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('products.changeStatus', $items->id )); ?>" class="btn btn-danger btn-sm">In-Active</a>
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <form method="post" action="<?php echo e(route('products.destroy',[$items->id])); ?>"  style="display: inline-block;">
                                            <a type="button" class="btn btn-outline-success btn-sm"
                                                href="<?php echo e(route('products.edit', $items->id )); ?>">
                                                Edit
                                            </a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input type="submit" value="Delete" class="btn btn-outline-danger btn-sm">

                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center">
                                        No Product exist in database.
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row mt-3 float-right">
                        <?php echo e($products->links("pagination::bootstrap-4")); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\globalCalcium\resources\views/components/product/index.blade.php ENDPATH**/ ?>