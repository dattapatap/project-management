<?php $__env->startSection('content'); ?>

<style>

</style>

<div class="container-fluid">
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0 font-size-18">Batch</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(env('APP_NAME')); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/batches')); ?>">Batch</a></li>
                        <li class="breadcrumb-item active">Create</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="header-title"> New Batch </h4>
                </div>
                <div class="card-body">
                    <form class="custom-validation" id="frm_batch" method="POST">
                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Brand Name  <span class="text_required">*</span></label>
                                    <select class="form-control select2" name="batch_name" id="batch_name" aria-placeholder="Brand" >
                                        <option>Select</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->brand_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="invalid-feedback" id="batch_name-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <label>Product <span class="text_required">*</span></label>
                                    <select class="form-control select2" name="product" id="product" aria-placeholder="Product" >
                                        <option value="">Select Product</option>
                                    </select>
                                    <span class="invalid-feedback" id="product-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>GTIN Number <span class="text_required">*</span></label>
                                    <input type="number" name="gtin_number" id="gtin_number" class="form-control"  placeholder="GTIN Number" readonly>
                                    <span class="invalid-feedback" id="gtin_number-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label>Product Description<span class="text_required">*</span></label>
                                    <input type="text" name="product_description" id="product_description" class="form-control"  placeholder="Product Description">
                                    <span class="invalid-feedback" id="product_description-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Batch No(ex-000000010).<span class="text_required">*</span></label>
                                    <input type="text" name="batch_number" class="form-control"  placeholder="Batch No."
                                    onkeypress="return isNumberKey(event)" maxlength="9">
                                    <span class="invalid-feedback" id="batch_number-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Batch Size <span class="text_required">*</span></label>
                                    <input type="number" name="batch_size" class="form-control"  placeholder="Batch Size">
                                    <span class="invalid-feedback" id="batch_size-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label> Gross Weight( .kg )<span class="text_required">*</span></label>
                                    <div class="input-group mt-3 mt-sm-0 mr-sm-3">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">Kg.</div>
                                        </div>
                                        <input type="number" name="gross_weight" class="form-control"  placeholder="Grass Weight">
                                    </div>
                                    <span class="invalid-feedback" id="gross_weight-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label> Tare Weight( .kg )<span class="text_required">*</span></label>
                                    <div class="input-group mt-3 mt-sm-0 mr-sm-3">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">Kg.</div>
                                        </div>
                                        <input type="number" name="tare_weight" class="form-control"  placeholder="Tare Weight">
                                    </div>
                                    <span class="invalid-feedback" id="tare_weight-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label> Net Weight( .kg )<span class="text_required">*</span></label>
                                    <div class="input-group mt-3 mt-sm-0 mr-sm-3">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">Kg.</div>
                                        </div>
                                        <input type="number" name="net_weight" class="form-control"  placeholder="Net Weight">
                                    </div>
                                    <span class="invalid-feedback" id="net_weight-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Drum No.<span class="text_required">*</span></label>
                                    <input type="number" name="drum_number" class="form-control"  placeholder="Drum Number">
                                    <span class="invalid-feedback" id="drum_number-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>

                        </div>

                        <hr>
                        <div class="row">

                            <div class="col-2">
                                <div class="form-group">
                                    <label>Total Drums<span class="text_required">*</span></label>
                                    <input type="number" name="tot_drums" class="form-control"  placeholder="Total no. of Drums">
                                    <span class="invalid-feedback" id="tot_drums-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Item Code<span class="text_required">*</span></label>
                                    <input type="text" name="item_code" class="form-control"  placeholder="Item Code">
                                    <span class="invalid-feedback" id="item_code-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Manufacture Date.<span class="text_required">*</span></label>
                                    <div class="input-group mt-3 mt-sm-0 mr-sm-3">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="mdi mdi-calendar-month"></i></div>
                                        </div>
                                        <input type="text" name="manufature_date" id="manufature_date" class="form-control"  placeholder="Manufature Date">
                                    </div>
                                    <span class="invalid-feedback" id="manufature_date-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Expiry Date<span class="text_required">*</span></label>
                                    <div class="input-group mt-3 mt-sm-0 mr-sm-3">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="mdi mdi-calendar-month"></i></div>
                                        </div>
                                        <input type="text" name="expiry_date" id="expiry_date" class="form-control"  placeholder="Expiry Date">
                                    </div>
                                    <span class="invalid-feedback" id="expiry_date-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>

                            <div class="col-2">
                                <div class="form-group">
                                    <label>Manufacture Lic. No.<span class="text_required">*</span></label>
                                    <input type="text" name="man_lic_number" class="form-control"  placeholder="Man. lic No.">
                                    <span class="invalid-feedback" id="man_lic_number-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="form-group">
                                    <label>Shipping Container Code<span class="text_required">*</span></label>
                                    <input type="text" name="shipping_code" class="form-control"  placeholder="Shipping Code">
                                    <span class="invalid-feedback" id="shipping_code-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group">
                                    <label>Special Storage Conditions<span class="text_required">*</span></label>
                                    <textarea  name="storage_condition" class="form-control"  placeholder="Special Storage Condition"></textarea>
                                    <span class="invalid-feedback" id="storage_condition-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>

                        </div>

                        <hr>
                        <div class="row float-roght">
                            <div class="col-12">
                                <button type="submit" class="creatBtn btn btn-primary waves-effect waves-light mr-1 float-right">
                                    Submit
                                </button>
                            </div>
                        </div>
                    </form>


                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

    $(document).ready(function(){

        $("#manufature_date").datepicker({
            todayHighlight: true,
            autoclose: true,
            format: 'dd-mm-yyyy',
            endDate: new Date()
        })
        $("#expiry_date").datepicker({
            todayHighlight: true,
            autoclose: true,
            format: 'dd-mm-yyyy',
            startDate : new Date(),
        })
        $('.select2').select2();

        $('#batch_name').change(function(){
            let brand_value = $(this).val();
            $('#product').empty().append('<option selected="selected" value="">Select Product</option>');
            $('#gtin_number').val('');
            $('#product_description').val('');
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('products.allproductsbybrandid')); ?>",
                data: {'brandid' : brand_value },
                success: function(response) {
                    if(response.status = true){
                        $("#product").select2({data :response.data });
                    }
                },
            });



        })

        $('#product').change(function(){
            let product_value = $(this).val();
            $('#gtin_number').val('');
            $('#product_description').val('');
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('products.getProductByid')); ?>",
                data: {'productid' : product_value },
                success: function(response) {
                    $("#gtin_number").val(response.data.gtin_no);
                    $("#product_description").val(response.data.product_desc);
                },
            });
        })


        $('#frm_batch').submit(function(e){

            e.preventDefault();
            var formData = new FormData($(this)[0]);
            $(".invalid-feedback").children("strong").text("");

            $.ajax({
                type: 'POST',
                url: '<?php echo e(route('batches.store')); ?>',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    $(".creatBtn").html('Creating..');
                    $(".creatBtn").prop('disabled', true);
                },
                success: function(response) {
                    console.log(response);
                    if (response.status == true) {
                        $('#frm_batch')[0].reset();
                        alertify.success(response.message);
                        setTimeout(() => {
                            window.location.href = "<?php echo e(route('batches.index')); ?>";
                        }, 1000);

                    } else {
                        alertify.error(response.message);
                        $(".creatBtn").prop('disabled', false);
                        $(".creatBtn").html('Submit');
                    }

                },
                error: function(response) {
                    console.log(response);
                    $(".creatBtn").prop('disabled', false);
                    $(".creatBtn").html('Submit');
                    if (response.responseJSON.status === 400) {
                        let errors = response.responseJSON.errors;
                        Object.keys(errors).forEach(function(key) {
                            $("#" + key + "Input").addClass("is-invalid");
                            $("#" + key + "-input-error").children("strong").text(errors[key][0]);
                        });
                    }
                }
            });
        });



    })

    function isNumberKey(evt){
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
        return true;
    }


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\globalCalcium\resources\views/components/batch/create.blade.php ENDPATH**/ ?>