<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0 font-size-18">Products</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(env('APP_NAME')); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/products')); ?>">Product</a></li>
                        <li class="breadcrumb-item active">Upload</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="offset-3 col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="header-title"> Upload Product </h4>
                </div>
                <div class="card-body">
                    <form id="productsUpload" class="custom-validation" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="alert alert-danger errors" style="display:none;">
                            <ul>
                            </ul>
                            <span><span>
                        </div>
                        <div class="alert alert-success success" style="display:none;">
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label>Brand Name  <span class="text_required">*</span></label>
                                    <select class="form-control <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> parsley-error  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="brand_name" aria-placeholder="Brand" >
                                        <option>Select</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('brand_name') == $item->id ? "selected" : ""); ?>  value="<?php echo e($item->id); ?>"><?php echo e($item->brand_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="invalid-feedback" id="brand_name-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label>Product File (.xlsx)  <span class="text_required">*</span></label>
                                    <span> For File Format
                                        <a href="<?php echo e(asset('docs/import.xlsx')); ?>" target="_blank"> Click </a>
                                    </span>
                                    <br>
                                    <input type="file"  name="product_file" class="form-control <?php $__errorArgs = ['product_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> parsley-error  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Product file" />
                                    <span class="invalid-feedback" id="product_file-input-error" role="alert">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="row float-roght">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary waves-effect waves-light mr-1 float-right uploadbtn">
                                    Submit
                                </button>
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        $("#activation_date").datepicker({
            todayHighlight: true,
            autoclose: true,
            format: 'dd-mm-yyyy',
            endDate: new Date()
        })
        $("#deactivate_date").datepicker({
            todayHighlight: true,
            autoclose: true,
            format: 'dd-mm-yyyy',
            startDate : new Date(),
        })
    })


    $('#productsUpload').submit(function(e) {
        e.preventDefault();
        var formData = new FormData($(this)[0]);
        $(".invalid-feedback").children("strong").text("");
        $("#productsUpload input").removeClass("is-invalid");
        $('.errors ul').empty();
        $('.errors span').empty();
        $('.success').empty();
        $('.errors').hide();
        $('.success').hide();

        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('products.uploadFile')); ?>",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function() {
                $(".uploadbtn").html('Uploading..');
                $(".uploadbtn").prop('disabled', true);
            },
            success: function(data) {
                if (data.code == 200) {
                    $('#productsUpload')[0].reset();
                    alertify.success(data.message);
                } else if (data.code === 201) {
                    $('.errors').append('<span>' + data.message + '</span>');
                    $('.errors').show();
                    $(".uploadbtn").prop('disabled', false); // enable button
                    $(".uploadbtn").html('Upload');

                } else if (data.code === 202) {

                    $(".uploadbtn").prop('disabled', false); // enable button
                    $(".uploadbtn").html('Upload');

                    var errors = data.error;
                    var lng = Object.keys(errors).length;
                    if (lng > 0) {
                        var list = '';
                        for (var key in errors) {
                            var inError = errors[key];
                            for (var txt in inError) {
                                console.log(inError[txt]);
                                list += '<li> Row ' + inError[txt]['row'] + ' - ' + inError[txt]['error'] + '</li>';
                            }
                        }
                        $('.errors ul').append(list);
                        $('.errors span').append(lng + ' - rows are not added, Please try again with correction of data');
                        $('.errors').show();
                    }

                    if (data.totRows > 0) {
                        $('.success').append('<span>' + data.totRows + ' Rows Uploaded </span>');
                        $('.success').show();
                    }

                } else if (data.code === 203) {
                    $(".uploadbtn").prop('disabled', false);
                    $(".uploadbtn").html('Save');
                    var errors = data.error;
                    var lng = Object.keys(errors).length;
                    if (lng > 0) {
                        var list = '';
                        for (var key in errors) {
                            var inError = errors[key];
                            for (var txt in inError) {
                                console.log(inError[txt]);
                                list += '<li> Row ' + inError[txt]['row'] + ' - ' + inError[txt]['error'] + '</li>';
                            }
                        }
                        $('.errors ul').append(list);
                        $('.errors span').append(lng + ' - rows are not added, Please try again with correction of data');
                        $('.errors').show();
                    }
                }
            },

            error: (response) => {
                console.log(response);
                $(".uploadbtn").prop('disabled', false);
                $(".uploadbtn").html('Upload');
                if (response.responseJSON.status === 400) {
                    let errors = response.responseJSON.errors;
                    Object.keys(errors).forEach(function(key) {
                        $("#" + key + "Input").addClass("is-invalid");
                        $("#" + key + "-input-error").children("strong").text(errors[key][0]);
                    });
                }
            }
        });

    })



</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\globalCalcium\resources\views/components/product/upload.blade.php ENDPATH**/ ?>