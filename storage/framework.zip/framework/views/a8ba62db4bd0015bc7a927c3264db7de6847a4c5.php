<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <style>
        @page
        {
            size: 177.80mm 101.60mm;
            margin-top: 15px;
            margin-left: 25px;
            margin-right: 25px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div>
        <table style="width: 100%;">
            <tbody>
                <tr style="width: 100%;">
                    <td style="width: 5%">

                    </td>
                    <td style="text-align: center; width: 95%;font-weight: 600;">
                        <h2 style="font-size:16pt;font-size: 16pt; padding: 0px;margin-top: 5px;margin-bottom: 0px;"></h2>
                        <p style="padding:0px;font-size:12pt;margin-top:20pt;margin-bottom: 0px;">  <?php echo e($batch['product']['product_name']); ?> </p>
                        <p style="padding:0px;font-size:10pt;margin-top:2px;">(ITEM CODE: <?php echo e($batch['item_code']); ?> )</p>
                    </td>
                </tr>
            </tbody>
        </table>
        <table style="width: 100%;">
            <tbody>
                <tr style="color: #000;font-size: 10pt;font-weight: 600;padding: 0px 5px">
                    <td>Batch No</td>
                    <td>:</td>
                    <td><?php echo e($batch['batch_no']); ?></td>
                    <td></td>
                    <td>Gross Wt.</td>
                    <td>:</td>
                    <td>  <?php echo e($batch['gross_weight']); ?> Kg.</td>
                </tr>
                <tr style="color: #000;font-size: 10pt;font-weight: 600;">

                    <td>Mfg.Date</td>
                    <td>:</td>
                    <td> <?php echo e(Carbon\Carbon::parse($batch['manf_date'])->format('d-m-Y')); ?> </td>
                    <td></td>
                    <td>Tare Wt</td>
                    <td>:</td>
                    <td><?php echo e($batch['tare_weight']); ?> Kg.</td>
                </tr>
                <tr style="color: #000;font-size: 10pt;font-weight: 600;">
                    <td>EXP.Date</td>
                    <td>:</td>
                    <td> <?php echo e(Carbon\Carbon::parse($batch['exp_date'])->format('d-m-Y')); ?> </td>
                    <td></td>
                    <td>Net Wt.</td>
                    <td>:</td>
                    <td> <?php echo e($batch['net_weight']); ?> Kg.</td>

                </tr>
                <tr style="color: #000;font-size: 10pt;font-weight: 600;">
                    <td>Mfg.Lic.No</td>
                    <td>:</td>
                    <td><?php echo e($batch['manf_lic_no']); ?></td>
                    <td style="width: 20%"></td>
                    <td rowspan="2">Total No. Of Drums</td>
                    <td rowspan="2">:</td>
                    <td rowspan="2">  <?php echo e($batch['tot_drums']); ?> </td>

                </tr>

                <tr style="color: #000;font-size: 10pt;font-weight: 600;">
                    <td>Drum.No</td>
                    <td>:</td>
                    <td> <?php echo e($batch['drum_no']); ?> </td>

                </tr>
            </tbody>
        </table>
        <table style="width: 100%;">
            <tbody>
                <tr style="text-align: right;margin-rigth:5px!important;">
                    <td colspan="2">
                        <h3 style="font-size: 10pt;"></h3>
                        <h3 style="color:#000;margin-top:5px;font-size: 10pt;margin-top:20pt"> <?php echo e($batch['storage_condition']); ?> </h3>
                    </td>
                </tr>
            </tbody>
        </table>
        <table style="width: 100%;">
            <tbody>
                <tr>
                    <td style="text-align: center;">
                        <img src="storage/<?php echo e($qrpath); ?>" alt="qrcode" style="width:60px;">
                    </td>
                </tr>

            </tbody>

        </table>
    </div>

</body>
<html>
<?php /**PATH D:\globalCalcium\resources\views/labels.blade.php ENDPATH**/ ?>